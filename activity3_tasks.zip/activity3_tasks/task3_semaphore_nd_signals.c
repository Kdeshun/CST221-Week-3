#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <signal.h>


sem_t semaphore;
pid_t child_pid;


void handle_sigchld(int sig) {
    wait(NULL); 
    printf("Parent: Child process terminated.\n");
}


void* monitor_thread(void* arg) {
    sleep(10);  

    if (sem_trywait(&semaphore) != 0) {
        
        pthread_exit((void*)1);
    } else {
       
        sem_post(&semaphore);
        pthread_exit((void*)0);
    }
}

int main() {
    
    if (sem_init(&semaphore, 1, 1) != 0) {
        perror("sem_init failed");
        exit(EXIT_FAILURE);
    }

    
    struct sigaction sa;
    sa.sa_handler = handle_sigchld;
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGCHLD, &sa, NULL) == -1) {
        perror("sigaction failed");
        exit(EXIT_FAILURE);
    }

    
    child_pid = fork();
    if (child_pid == -1) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (child_pid == 0) {
        // Child process
        sem_wait(&semaphore);  
        printf("Child: obtained semaphore, simulating long-running task...\n");
        sleep(60);  
        sem_post(&semaphore);  
        exit(EXIT_SUCCESS);
    } else {
       
        pthread_t thread;
        void* thread_result;

        
        if (pthread_create(&thread, NULL, monitor_thread, NULL) != 0) {
            perror("pthread_create failed");
            exit(EXIT_FAILURE);
        }

       
        if (pthread_join(thread, &thread_result) != 0) {
            perror("pthread_join failed");
            exit(EXIT_FAILURE);
        }

        if ((int)thread_result == 1) {
            
            printf("Parent: failed to obtain semaphore, terminating child process...\n");
            kill(child_pid, SIGKILL);
           
            pause();
        }

       
        if (sem_trywait(&semaphore) == 0) {
            printf("Parent: obtained semaphore after terminating child process.\n");
            sem_post(&semaphore);
        } else {
            printf("Parent: failed to obtain semaphore even after terminating child process.\n");
        }

        
        if (sem_destroy(&semaphore) != 0) {
            perror("sem_destroy failed");
            exit(EXIT_FAILURE);
        }
    }

    return 0;
}

