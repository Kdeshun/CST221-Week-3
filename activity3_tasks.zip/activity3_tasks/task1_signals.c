#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>


#define BUFFER_SIZE 1024


typedef struct {
    char buffer[BUFFER_SIZE];
    int in;
    int out;
} CircularBuffer;

CircularBuffer *sharedBuffer;


void handle_sigusr1(int sig);


void send_data_and_signal_consumer(const char *message) {
 
    for (size_t i = 0; i < strlen(message); ++i) {
        sharedBuffer->buffer[sharedBuffer->in] = message[i];
        sharedBuffer->in = (sharedBuffer->in + 1) % BUFFER_SIZE;
        kill(getpid() + 1, SIGUSR1); 
        usleep(100000); 
    }
    
    sharedBuffer->buffer[sharedBuffer->in] = '\0';
    sharedBuffer->in = (sharedBuffer->in + 1) % BUFFER_SIZE;
    kill(getpid() + 1, SIGUSR1);
}

int main() {
   
    int fd = shm_open("/shm_buffer", O_CREAT | O_RDWR, 0666);
    ftruncate(fd, sizeof(CircularBuffer));
    sharedBuffer = mmap(NULL, sizeof(CircularBuffer), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

  
    sharedBuffer->in = 0;
    sharedBuffer->out = 0;

    
    pid_t pid = fork();

    if (pid > 0) { 
        
        usleep(100000); 

  
        const char *message = "David"; 
        send_data_and_signal_consumer(message);

       
        wait(NULL);
    } else if (pid == 0) { 
     
        signal(SIGUSR1, handle_sigusr1);

        
        while (1) {
            pause();
        }
    } else {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

   
    munmap(sharedBuffer, sizeof(CircularBuffer));
    shm_unlink("/shm_buffer");

    return 0;
}


void handle_sigusr1(int sig) {
    
    char c = sharedBuffer->buffer[sharedBuffer->out];
    sharedBuffer->out = (sharedBuffer->out + 1) % BUFFER_SIZE;

   
    printf("Received: %c\n", c);

   
    if (c == '\0') {
        printf("Received null character. Exiting.\n");
        exit(0);
    }
}

