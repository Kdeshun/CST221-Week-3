#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>


int counter = 0;
int misses = 0;
int runtime_seconds;
pthread_mutex_t counter_mutex = PTHREAD_MUTEX_INITIALIZER;


void* counter_thread(void* arg);
void* monitor_thread(void* arg);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <runtime in minutes>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int runtime_minutes = atoi(argv[1]);
    runtime_seconds = runtime_minutes * 60;


    pthread_t counter_tid, monitor_tid;
    if (pthread_create(&counter_tid, NULL, counter_thread, NULL)) {
        fprintf(stderr, "Error creating counter thread\n");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&monitor_tid, NULL, monitor_thread, NULL)) {
        fprintf(stderr, "Error creating monitor thread\n");
        exit(EXIT_FAILURE);
    }

 
    pthread_join(counter_tid, NULL);
    pthread_join(monitor_tid, NULL);


    printf("Final counter value: %d\n", counter);
    printf("Misses count: %d\n", misses);

    return 0;
}


void* counter_thread(void* arg) {
    for (int i = 0; i < runtime_seconds; i++) {
        pthread_mutex_lock(&counter_mutex);
        counter++;
        printf("Counter value (counter_thread): %d\n", counter);
        sleep(1); 
        pthread_mutex_unlock(&counter_mutex);
    }
    printf("Counter thread exiting. Final counter value: %d\n", counter);
    return NULL;
}


void* monitor_thread(void* arg) {
    for (int i = 0; i < runtime_seconds / 3; i++) {
        sleep(3); 
        if (pthread_mutex_trylock(&counter_mutex) == 0) {
            printf("Counter value (monitor): %d\n", counter);
            pthread_mutex_unlock(&counter_mutex);
        } else {
            misses++;
            printf("Missed reading counter\n");
        }
    }
    printf("Monitor thread exiting. Misses count: %d\n", misses);
    return NULL;
}

